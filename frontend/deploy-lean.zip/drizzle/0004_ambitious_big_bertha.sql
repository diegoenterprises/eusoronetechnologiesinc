ALTER TABLE `geofences` ADD `alertOnEnter` boolean DEFAULT true;--> statement-breakpoint
ALTER TABLE `geofences` ADD `alertOnExit` boolean DEFAULT true;